#ifndef GRAPH_H
#define GRAPH_H

#include "graph_abstract.hpp"

#include <iostream>
#include <vector>
#include <cmath>
#include <stdint.h>

#include <opencv2/opencv.hpp>
#include <eigen3/Eigen/Dense>

#define VNAME(value) (#value)

using namespace cv;
using namespace Eigen;
using namespace std;

class __graph {
public:

    __graph();

    __graph(uint32_t _x_max, uint32_t _y_max);

    ~__graph();

    MatrixXd get_graphMat() { return graphMat; }        // 读取矩阵

    void     set_graphMat(MatrixXd in) {                // 设置矩阵

        int x, y;

        graphMat = in;
        x_max = in.cols();
        y_max = in.rows();

        for (y = 0; y < graphMat.rows(); y++) {
            for (x = 0; x < graphMat.cols(); x++) {
                if (graphMat(y, x) == 0.0f)
                    graphMat(y, x) = 0.0f;
                else
                    graphMat(y, x) = 1.0f;
            }
        }
    }

    uint32_t get_x_max() {                              // 返回矩阵列数
        x_max = graphMat.cols();
        return x_max;
    }

    uint32_t get_y_max() {                              // 返回矩阵行数
        y_max = graphMat.rows();
        return y_max;
    }

    double get_Pixel(uint32_t x, uint32_t y) {          // 获得某一个像素点的值
        if (x > x_max || y > y_max)
            return -1.;
        else
            return graphMat(y, x);
    }

    bool set_Pixel(double in, uint32_t x, uint32_t y) { // 强制设置某一个像素点
        if (x > x_max || y > y_max)
            return false;
        else {
            if (in != 0.0f)
                graphMat(y, x) = 1;
            else
                graphMat(y, x) = 0;
            return true;
        }
    }

    MatrixXd calc_AdjacencyMatrix();                    // 计算邻接矩阵

    MatrixXd calc_AdjMat_Reciprocal();                  // 计算邻接矩阵的倒数

    void print();                                       // 终端打印

    void draw(bool is_show);                            // 用OpenCV画出来，如果用is_show显示，窗口名是固定的，graph_test

    void draw(String winName, bool is_show);            // 用OpenCV画出来，名称自定

    void show_Img(String winName);                      // 只打印图象

protected:

    static const int32_t img_grid_len = 10;

    MatrixXd graphMat;

    uint32_t x_max, y_max;

    MatrixXd D;                 // 邻接矩阵

    Mat      img;

};

#endif // GRAPH_H

