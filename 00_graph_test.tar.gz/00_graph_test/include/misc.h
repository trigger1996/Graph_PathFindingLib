#ifndef MISC_H
#define MISC_H

#endif // MISC_H

