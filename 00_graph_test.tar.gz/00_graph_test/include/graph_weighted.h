#ifndef GRAPH_WEIGHTED_H
#define GRAPH_WEIGHTED_H

#include "graph_abstract.h"

#include <iostream>
#include <vector>
#include <cmath>
#include <stdint.h>

#include <opencv2/opencv.hpp>
#include <eigen3/Eigen/Dense>

using namespace cv;
using namespace Eigen;
using namespace std;

class __graph_weighted : public __graph_abstract {
public:

    __graph_weighted() : __graph_abstract() {
        maxval = minval = 0;
    }

    __graph_weighted(uint32_t _x_max, uint32_t _y_max) : __graph_abstract(_x_max, _y_max) {
        maxval = minval = 0;
    }

    ~__graph_weighted() {

    }

    double get_Pixel(uint32_t x, uint32_t y) {           // 获得某一个像素点的值

    }
    void set_graphMat(MatrixXd in) {                     // 设置矩阵

    }

    bool set_Pixel(double in, uint32_t x, uint32_t y) {  // 强制设置某一个像素点

    }
    MatrixXd calc_AdjacencyMatrix() {                    // 计算邻接矩阵

    }
    MatrixXd calc_AdjMat_Reciprocal() {                  // 计算邻接矩阵的倒数

    }
    void print() {                                       // 终端打印

    }

    void draw(bool is_show) {                            // 用OpenCV画出来，如果用is_show显示，窗口名是固定的，graph_test

    }

protected:

    double maxval, minval;

    void calc_Maxval();

    void calc_Minval();
};

#endif // GRAPH_WEIGHTED_H

