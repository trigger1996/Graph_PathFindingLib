#ifndef GRAPH_ABSTRACT_HPP
#define GRAPH_ABSTRACT_HPP

#include <iostream>
#include <vector>
#include <cmath>
#include <stdint.h>

#include <opencv2/opencv.hpp>
#include <eigen3/Eigen/Dense>

#define VNAME(value) (#value)

using namespace cv;
using namespace Eigen;
using namespace std;

class __graph_abstract {
public:

    __graph_abstract() {
        graphMat.resize(1, 1);
        graphMat.fill(0);

        x_max = y_max = 1;
    }

    __graph_abstract(uint32_t _x_max, uint32_t _y_max) {
        graphMat.resize(_y_max, _x_max);
        graphMat.fill(0);

        x_max = _x_max;
        y_max = _y_max;
    }

    ~__graph_abstract() {
        graphMat.resize(0, 0);

        x_max = 0;
        y_max = 0;
    }


/// 实函数
    MatrixXd get_graphMat() { return graphMat; }                // 读取矩阵

    uint32_t get_x_max() {                                      // 返回矩阵列数
        x_max = graphMat.cols();
        return x_max;
    }

    uint32_t get_y_max() {                                      // 返回矩阵行数
        y_max = graphMat.rows();
        return y_max;
    }
/// 虚函数，用作接口
    virtual double get_Pixel(uint32_t x, uint32_t y);           // 获得某一个像素点的值

    virtual void set_graphMat(MatrixXd in);                     // 设置矩阵

    virtual bool set_Pixel(double in, uint32_t x, uint32_t y);  // 强制设置某一个像素点

    virtual MatrixXd calc_AdjacencyMatrix();                    // 计算邻接矩阵

    virtual MatrixXd calc_AdjMat_Reciprocal();                  // 计算邻接矩阵的倒数

    virtual void print();                                       // 终端打印

    virtual void draw(bool is_show);                            // 用OpenCV画出来，如果用is_show显示，窗口名是固定的，graph_test

/// 两个升级版的画图操作
    void draw(String winName, bool is_show) {                   // 用OpenCV画出来，名称自定
        draw(false);

        if (is_show) {
            namedWindow(winName, WINDOW_NORMAL);
            imshow(winName, img);
            waitKey(1);
        }
    }

    void show_Img(String winName) {                              // 只打印图象
        namedWindow(winName, WINDOW_NORMAL);
        imshow(winName, img);
        waitKey(1);
    }

protected:

    static const int32_t img_grid_len = 10;

    MatrixXd graphMat;

    uint32_t x_max, y_max;

    MatrixXd D;                                                 // 邻接矩阵

    Mat      img;

};

#endif // GRAPH_ABSTRACT_HPP

