#include <iostream>
#include "include/graph.h"
#include "include/graph_weighted.h"

using namespace Eigen;
using namespace cv;
using namespace std;

int main(void) {

    MatrixXd mat_test;
    MatrixXd _D, _D_rec;
    __graph example_graph(10, 10);
    __graph_weighted example_graph_weighted(10, 10);

    /// 测试内容1：从类中读取矩阵并打印
    mat_test = example_graph.get_graphMat();
    cout << mat_test << endl << endl;

    /// 测试内容2： 写入新的矩阵，并使用类中方法打印
    mat_test << 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                1, 0, 0, 1, 1, 1, 1, 1, 1, 1,
                1, 0, 0, 1, 1, 1, 1, 1, 1, 1,
                1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                1, 1, 1, 1, 1, 0, 0, 0, 0, 1,
                1, 1, 1, 1, 0, 0, 0, 0, 1, 1,
                1, 1, 1, 1, 1, 0, 0, 1, 1, 1,
                1, 1, 1, 1, 1, 0, 0, 1, 1, 1,
                1, 1, 1, 1, 1, 1, 1, 1, 1, 1;
    example_graph.set_graphMat(mat_test);
    example_graph.print();

    /// 测试内容3： 作出新矩阵的图像
    //example_graph.draw(true);
    example_graph.draw("example_graph", true);

    /// 测试内容4： 计算邻接矩阵，读取，并打印
    _D = example_graph.calc_AdjacencyMatrix();
    //cout << endl;
    //cout << _D << endl;

    /// 测试内容5： 计算邻接矩阵倒数
    _D_rec = example_graph.calc_AdjMat_Reciprocal();
    //cout << endl;
    //cout << _D_rec << endl;

/*
    /// 测试内容6： 有权图写入新的矩阵，并使用类中方法打印
    mat_test.resize(5, 5);
    mat_test << 10,  7,   6.5, 4.5, 1.8,
                8,   0,   0,   3,   1.5,
                6,   0,   0,   0,   1.2,
                4,   3,   2,   1,   0.8,
                1.8, 1.5, 1.2, 0.8, 0.5;
    example_graph_weighted.set_graphMat(mat_test);
    cout << endl;
    example_graph_weighted.print();

    /// 测试内容7： 有权图使用OpenCV打印
    example_graph_weighted.draw(true);      // "example_graph_weighted", true

    /// 测试内容8： 有权图打印邻接矩阵
    _D = example_graph_weighted.calc_AdjacencyMatrix();
    cout << _D << endl << endl;
*/

//  cout << 233 << endl;
    waitKey(0);
    return 0;

}// main
